<?php
$servidor = "localhost";
$usuario = "uv029723";
$contrasena = "Sistemas3141";
$basededatos = "cac22586";

$conexion = mysqli_connect($servidor, $usuario, $contrasena) or die ("No se conecto al servidor");

$db = mysqli_select_db($conexion, $basededatos) or die ("No se conecto a la base");

if  ( ( isset($_POST['Alta'])) ) {

     extract($_POST);

       
   
    $sql="INSERT INTO oradores(nombre, apellido, tema, email) VALUES ('$nombre', '$apellido', '$tema', '$email')";
    
    $result=mysqli_query($conexion, $sql);

    if (!$result) {

        echo 'Fallo la carga';
        die();
    }



}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Integrador JavaScript Codo a Codo</title>
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet"/>
    <!-- CSS adicional -->
    <link rel="stylesheet" href="css/estilos.css" />
</head>

<body>
    <header>
        <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <img src="img/codoacodo.png" alt="Logo de Codo a Codo" />
                    Conf Bs As
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="#conferencia">La Conferencia</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#oradores">Los oradores</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#lugar">El lugar y la fecha</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#serOrador">Conviértete en orador</a>

                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="comprar-tickets" href="comprar.html">Comprar tickets</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main>
        <!-- Sección de la Conferencia -->
       
        <!-- Sección de los Oradores -->
       
        <!-- Sección Ser un Orador -->
        <section id="serOrador" class="container" >
            <div class="row justify-content-center">
                <div class="col-lg-7 col-xl-8">
                    <p class="text-center">Conviértete en un</p>
                    <h2 class="text-center">ORADOR</h2>
                    <p class="text-center"></p>
                    <form action="alta.php" method="post" enctype="multipart/form-data" name="contact-form" >
                        <div class="row gx-2">
                            <div class="form-floating col-md mb-3">
                                <input name="nombre" id="nombreOrador" type="text" class="form-control" placeholder="Nombre" aria-label="Nombre" required>
                                <label for="nombreOrador">Nombre</label>
                            </div>
                            <div class="form-floating col-md mb-3">
                                <input name="apellido" id="apellidoOrador" type="text" class="form-control" placeholder="Apellido" aria-label="Apellido" required>
                                <label for="apellidoOrador">Apellido</label>
                            </div>
                        </div>
                        <div class="row gx-2">
                            <div class="form-floating col-md mb-3">
                                <input name="email" id="correoOrador" type="email" class="form-control" placeholder="Email" aria-label="Email" required>
                                <label for="correoOrador">Correo</label>
                            </div>
                        </div>
                       <!-- <div class="row gx-2">
                            <div class="form-floating col-md mb-3">
                                <input name="telefono" id="correoOrador" type="number" class="form-control" placeholder="Telefono" aria-label="Telefono" required>
                                <label for="correoOrador">Teléfono</label>
                            </div>
                        </div>-->
                        <div class="row">
                            <div class="col mb-3">
                                <textarea name="tema" class="form-control" id="exampleFormControlTextarea1" rows="4"
                                    placeholder="Sobre qué quieres hablar?" required></textarea>
                                <div id="emailHelp" class="form-text mb-3">Recuerda incluir un título para tu charla.</div>
                                 <div class="d-grid">
                                    <button type="submit" name="Alta" class="btn btn-success btn-lg btn-form">Enviar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                      <a href="oradores.php">Volver</a>
                </div>
            </div>
        </section>
    </main>
    <footer>
        <div class="contenedor footer-info">
            <a href="Preguntas frecuentes" class="link-info">Preguntas frecuentes</a>
            <a href="Contáctanos" class="link-info">Contáctanos</a>
            <a href="Prensa" class="link-info">Prensa</a>
            <a href="Conferencias" class="link-info">Conferencias</a>
            <a href="Términos y condiciones" class="link-info">Términos y condiciones</a>
            <a href="Privacidad" class="link-info">Privacidad</a>
            <a href="Estudiantes" class="link-info">Estudiantes</a>
        </div>
    </footer>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8"
        crossorigin="anonymous"></script>
    <!-- Mi JS -->
    <script src="js/index.js"></script>
</body>

</html>


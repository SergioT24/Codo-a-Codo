<?php
 $servidor = "localhost";
 $usuario = "uv029723";
 $contrasena = "Sistemas3141";
 $basededatos = "cac22586";

 $conexion = mysqli_connect($servidor, $usuario, $contrasena) or die ("No se conecto al servidor");

 $db = mysqli_select_db($conexion, $basededatos) or die ("No se conecto a la base");
 
 $id=$_REQUEST["id"];
 $sql="delete from oradores where id='$id'";
 $result=mysqli_query($conexion, $sql);
 
 echo "Orador Borrado ID= ".$id;
 echo '<br>';
 echo "<a href=oradores.php>Volver</a>"
 ?>

<?php
 $servidor = "localhost";
 $usuario = "uv029723";
 $contrasena = "Sistemas3141";
 $basededatos = "cac22586";

 $conexion = mysqli_connect($servidor, $usuario, $contrasena) or die ("No se conecto al servidor");

 $db = mysqli_select_db($conexion, $basededatos) or die ("No se conecto a la base");


 /******************************************************/
/* Funcion paginar
 * actual:          Pagina actual
 * total:           Total de registros
 * por_pagina:      Registros por pagina
 * enlace:          Texto del enlace
 * maxpags:         El m&aacute;ximo de p&aacute;ginas a presentar simult&aacute;neamente (opcional)
 * Devuelve un texto que representa la paginacion
 */
function paginar($actual, $total, $por_pagina, $enlace, $maxpags=10) {
    $total_paginas = ceil($total/$por_pagina);
    $anterior = $actual - 1;
    $posterior = $actual + 1;
    $minimo = $maxpags ? max(1, $actual-ceil($maxpags/2)): 1;
    $maximo = $maxpags ? min($total_paginas, $actual+floor($maxpags/2)): $total_paginas;
    if ($actual>1)
      $texto = "<li><a href=\"$enlace$anterior\">Ant</a></li>";
    else
      $texto = "<li><a >Ant</li>";
    if ($minimo!=1) $texto.= "<li><a >...</a></li>";
    for ($i=$minimo; $i<$actual; $i++)
      $texto .= "<li><a href=\"$enlace$i\">$i</a></li>";
    $texto .= "<li class=\"active\"><a >$actual</a></li>";
    for ($i=$actual+1; $i<=$maximo; $i++)
      $texto .= "<li><a href=\"$enlace$i\">$i</a></li>";
    if ($maximo!=$total_paginas) $texto.= "<li><a >...</a></li>";
    if ($actual<$total_paginas)
      $texto .= "<li><a href=\"$enlace$posterior\">Sig</a></li>";
    else
      $texto .= "<li><a >Sig</a></li>";
    return $texto;
  }
/**********************************************************/
 ?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous" />
    <!-- CSS adicional -->
    <link rel="stylesheet" href="css/estilos.css" />
</head>

<body>
    <header>
        <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <img src="img/codoacodo.png" alt="Logo de Codo a Codo" />
                    Conf Bs As
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="index.html#conferencia">La Conferencia</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.html#oradores">Los oradores</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.html#lugar">El lugar y la fecha</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.html#serOrador">Conviértete en orador</a>

                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="comprar-tickets" href="comprar.html">Comprar tickets</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <main>

        <!-- otrapersona -->
        <section id="descripcionCategoria" class="container">
            <div  class="row justify-content-center">
                <p>Buscar</p>

  <a href="alta.php">Nuevo Orador</a>        
<table>

<tr>
    <th>Nombre</th>
    <th>Apellido</th>
    <th>Email</th>
   
    <th>Tema</th>
    <th>Modificar</th>
    <th>Borrar</th>

</tr>
  <?php 

/*$pag=$_GET["pag"];
if (!isset($pag)) $pag = 1; // Por defecto, pagina 1
$tampag = 5;
$columna = 1;
$reg1 = ($pag-1) * $tampag;*/


  $sql="select * from oradores";
  $result=mysqli_query($conexion, $sql);
  ?>
  <?php
  $linea=1;
  while ($row = mysqli_fetch_array($result)) {

    //$total = mysqli_num_rows($result);

/*for ($i=$reg1; $i<min($reg1+$tampag, $total); $i++) {
    mysqli_data_seek($result, $i);
	$row = mysqli_fetch_array($result);*/
  ?>
<tr>
     <td><?php echo $row["id"] ?> - <?php echo $row["nombre"] ?></td>
     <td><?php echo $row["apellido"] ?></td>
     <td><?php echo $row["email"] ?></td>
     <td><?php echo $row["tema"] ?></td>
     <td> <a href="modificar.php?id=<?php echo $row["id"] ?>">Modificar</a></td>
     <td><a href="borrar.php?id=<?php echo $row["id"] ?>">borrar</a></td>
</tr>
<?php 
   $linea++;
   } ?>
</table>
<div class="pagination pagination-centered">
						  <ul>
							<?php 
							        //echo paginar($pag, $total, $tampag, "oradores.php?pag=");
							     ?>
						  </ul>
						</div>     
<br><br>

                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </section>


    </main>

    <footer>
        <div class="contenedor footer-info">
            <a href="Preguntas frecuentes" class="link-info">Preguntas frecuentes</a>
            <a href="Contáctanos" class="link-info">Contáctanos</a>
            <a href="Prensa" class="link-info">Prensa</a>
            <a href="Conferencias" class="link-info">Conferencias</a>
            <a href="Términos y condiciones" class="link-info">Términos y condiciones</a>
            <a href="Privacidad" class="link-info">Privacidad</a>
            <a href="Estudiantes" class="link-info">Estudiantes</a>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8"
        crossorigin="anonymous"></script>
    <!-- Mi JS -->
    <script src="js/index.js"></script>
</body>

</html>